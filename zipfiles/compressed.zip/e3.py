import shutil

#create copy files, extract files, zip files

shutil.make_archive("output","zip","friends_file")
